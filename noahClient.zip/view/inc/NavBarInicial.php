<nav class="navbar navbar-expand-lg navbar-light bg-light bg-white" ondragstart="return false" onselectstart="return false" oncontextmenu="return false">
    <div class="container">
        <img class="navbar-brand nav_img" height="60" src="<?php echo SERVERURL ?>view/assets/img/icon_nav.png">
        <!-- <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavDropdown" aria-controls="navbarNavDropdown" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button> -->
<!--        <div class="collapse navbar-collapse" id="navbarNavDropdown">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link active" aria-current="page" href="#">Yo</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Mi Mascota</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Su condición</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Pre-Checkout</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#"></a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Alimento</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Dieta</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" href="#">Checkout</a>
                </li>
            </ul>
        </div>-->
    </div>
</nav>