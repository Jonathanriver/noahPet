 <!-- popper -->
 <!-- <script src="<?php echo SERVERURL; ?>view/js/popper.min.js"></script> -->
 
<!-- JavaScript Bundle with Popper -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/js/bootstrap.bundle.min.js" integrity="sha384-A3rJD856KowSb7dwlZdYEkO39Gagi7vIsF0jrRAoQmDKKtQBHUuLZ9AsSv4jD4Xa" crossorigin="anonymous"></script>
 
 <!-- Jquey  -->
 <script src="<?php echo SERVERURL; ?>view/js/jquery-3.6.0.min.js"></script>

