 <!-- Normalize V8.0.1 -->
 <!-- <link rel="stylesheet" href="<?php echo SERVERURL; ?>view/css/normalize.css"> -->

 <!-- Bootstrap V5.2 -->
 <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

 <!-- Bootstrap Icons 1.9.1-->
 <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.9.1/font/bootstrap-icons.css">

 <!-- Font Awesome V5.9.0 -->
 <!-- <link rel="stylesheet" href="<?php echo SERVERURL; ?>view/css/all.css"> -->

 <!-- Sweet Alerts V8.13.0 CSS file -->
 <!-- <link rel="stylesheet" href="<?php echo SERVERURL; ?>view/css/sweetalert2.min.css"> -->

 <!-- Sweet Alert V8.13.0 JS file-->
 <!-- <script src="<?php echo SERVERURL; ?>view/js/sweetalert2.min.js"></script> -->

 <!-- jQuery Custom Content Scroller V3.1.5
 <link rel="stylesheet" href="<?php echo SERVERURL; ?>view/css/jquery.mCustomScrollbar.css"> -->

 <!-- General Styles -->
 <link rel="stylesheet" href="<?php echo SERVERURL; ?>view/css/styles.css">
